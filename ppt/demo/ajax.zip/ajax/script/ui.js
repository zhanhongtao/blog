

var ui = {};

ui.devices = (function() {
    var devicesBox = document.querySelector( '#devices-box' );
    function show( list ) {
        if ( list && list.length ) {
            fragment = document.createDocumentFragment();
            var current = currentUUID.get();
            list.forEach(function( item ) {
                var radio = document.createElement( 'input' );
                radio.type = 'radio';
                radio.name = 'devices_uuid',
                radio.value = item.uuid;
                radio.id = 'uuid_' + item.uuid;
                radio.checked = current === item.uuid ? true : false;
                var label = document.createElement( 'label' );
                label.setAttribute( 'for', 'uuid_' + item.uuid );
                label.innerText = item.name;
                fragment.appendChild( radio );
                fragment.appendChild( label );
            });
            devicesBox.innerHTML = '';
            var removeButton = document.createElement( 'button' );
            removeButton.id = 'unbind-device';
            removeButton.innerHTML = '解除设备';
            fragment.appendChild( removeButton );
            devicesBox.appendChild( fragment );
        }
        else {
            var tip = '不存在绑定设备 - 扫描二维码绑定设备';
            devicesBox.innerHTML = tip;
        }
    }
    
    devicesBox.addEventListener( 'click', function(e) {
      var target = e.target;
      if ( target.nodeType === 1 && target.tagName.toLowerCase() === 'input' ) {
        currentUUID.set( target.value );
      }
    }, false );
    return {
        show: show
    };
})();

ui.qrcode = (function() {
    var qrcode = new QRCode( 'qrbox' );
    var qrbox = document.querySelector( '#qrbox' );
    return {
        create: function ( qr ) {
            qrcode.makeCode( qr );
            qrbox.style.display = 'block';
        },
        clear: function() {
            qrbox.style.display = 'none';
        }
    };
})();

ui.layer = (function() {
    var layer = document.querySelector( '#layer' );
    return {
        show: function() {
            layer.style.display = 'block';
        },
        hide: function() {
            layer.style.display = 'none';
        }
    };
})();

ui.request = (function() {
    var loading = document.querySelector( '#loading' );
    var timer;
    function sendRequestStart() {
        loading.style.display = 'block';
    }
    function sendRequestEnd() {
        if ( timer ) clearTimeout( timer );
        timer = setTimeout(function() {
            loading.style.display = 'none';
        }, 500);
    }
    return {
        sendRequestStart: sendRequestStart,
        sendRequestEnd: sendRequestEnd
    };
})();

ui.bindDevice = function() {
    document.addEventListener( 'click', function( event ) {
        var target = event.target;
        if ( target.webkitMatchesSelector('#bind-new-device') ) {
            return createQRcode();
        }

        if ( target.webkitMatchesSelector('#unbind-device') ) {
            delDevices( currentUUID.get(), initApp );
        }
    }, false );
};

ui.capability = function() {
    var textarea = document.querySelector( '#send-text' );
    document.addEventListener( 'click', function( event ) {
        var target = event.target;
        if ( target.webkitMatchesSelector( '#send-text-now') ) {
            var content = textarea.value.trim();
            if ( content ) {
                sendText({
                    text: content,
                    title: ''
                }, function() {
                    setTimeout(function() {
                        textarea.value = '';
                    }, 2 * 1000);
                });
            }
            else {
                textarea.focus();
            }
        }
        else if ( target.webkitMatchesSelector( '#send-current-tab' ) ) {
            // @TODO: 封装 api, 兼容其它浏览器.
            var tabapi = new mx.browser.tabs();
            var tab = tabapi.getCurrentTab();
            sendURL({
                url: tab.url,
                title: tab.title
            });
        }
    }, false );

    var filesInput = document.querySelector( '#files' );
    filesInput.addEventListener( 'change', function() {
        sendFiles( this.files );
    });
};

ui.initFilesFront = function() {
    document.querySelector( '#send-text' ).addEventListener( 'drop', function(e) {
        var text = e.dataTransfer.getData('text/plain');
        if ( text ) {
            e.stopImmediatePropagation();
        }
    }, false);

    // 防止在落在 html 中, 在页面打开文件.
    // 拖拽到页面上效果.
    var html = document.querySelector( 'html' );
    html.addEventListener( 'dragenter', function(e) {
        if ( e.dataTransfer.files.length > 0 ) {
            e.preventDefault();
        }
    }, false );

    html.addEventListener( 'dragover', function(e) {
        if ( e.dataTransfer.files.length > 0 ) {
            e.preventDefault();
        }
    }, false );

    html.addEventListener( 'drop', function(e) {
        var files = e.dataTransfer.files;
        if ( files && files.length > 0 ) {
            sendFiles( files );
            e.preventDefault();
        }
    }, false );
};

ui.uploadProgress = function( current, total ) {
    console.log( 'ui progress: ', current, total );
    var progress = document.querySelector( '.upload-progress' );
    progress.style.width = ( current / total ) * 100 + '%';
    if ( current / total === 1 ) {
        setTimeout(function() {
            progress.style.width = '0%';
        }, 2 * 1000);
    }
};

ui.uploadError = function( text ) {
    var progress = document.querySelector( '.upload-progress' );
    progress.style.width = '100%';
    progress.style.backgroundColor = 'red';
    setTimeout(function() {
        progress.style.width = 0;
        progress.style.backgroundColor = 'white';
    });
};

ui.exceedLimitedFileSize = function( files ) {
    console.log( '文件大小超过限制: ' );
    files.forEach(function( file ) {
        console.log( file.name, file.type, file.size );
    });
    ui.uploadError();
}

ui.init = function ( list ) {
    ui.devices.show( list );
    ui.layer[ list.length ? 'hide' : 'show' ]();
};

ui.bindDevice();
ui.capability();
ui.initFilesFront();

