

// @NOTE:
// 生成二维码的代码, 使用别人的.
// 生成 hid 的代码, 使用飞传 chrome 插件里面的.

// @TODO:
// 对应用添加 version 机制.
// 使用 event 机制, 对逻辑和界面解耦.
// 封装 ajax 操作, 支持 promise.

var storage_key_hid = 'com.sogou.feichuan.hid';
var current_uuid_key = 'com.sogou.feichuan.currentuuid';
var default_pc_name = (function() {
    // @TODO: 支持其它浏览器.
    // // 等服务器支持自定义 name 吧！
    return 'PC-Maxthon' + (''+Math.random()).slice(2, 6);
})();

var noop = function() {};

function requestQRData( cb ) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if ( xhr.readyState === 4 ) {
            if ( (xhr.status >= 200 && xhr.status < 300) || xhr.status === 304 ) {
                cb( xhr.responseText );
            }
            else {
                console.log( 'server error, please try again!' );
                alert( 'please try again' );
            }
        }
    };
    xhr.open( 'GET', 'http://sync.mse.sogou.com/findcouple?hid=' + getHid() + '&pcname=' + encodeURIComponent(default_pc_name), true );
    xhr.send( null );
}

/**
    ret: 1 // 失败.
    ret: 0 // 成功.
*/
var longRequest = (function createLongRequest( cb ) {
    var xhr;
    cb = typeof cb === 'function' ? cb :noop;
    function sendRequest() {
        xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if ( xhr.readyState === 4 ) {
                var requestEnd = false;
                if ( xhr.status >= 200 && xhr.status < 300 || xhr.status === 304 ) {
                    var responseText = xhr.responseText.toLowerCase();
                    if ( responseText.indexOf('ok') > -1 ) {
                        requestEnd = true;
                    }
                    xhr = null;
                    requestEnd ? cb({ret: 0}) : sendRequest( cb );
                }
                else {
                    // 网络连接失败.
                    // 手动 abort.
                    // 不再轮询处理.
                    xhr = null;
                }
            }
        };
        xhr.addEventListener( 'abort', function( event ) {
            console.log( 'abort', event )
        }, false );
        xhr.open( 'GET', 'http://sync.mse.sogou.com/checkbind?hid=' + getHid(), true );
        xhr.send( null );
        return xhr;
    }
    return function() {
        return xhr || sendRequest();
    };
})(function( responseText ) {
    checkDevicesPair( launchApp );
});

function stopLongRequest() {
    var xhr = longRequest();
    if ( xhr ) xhr.abort();
}

function createQRcode() {
    requestQRData( function( qrInformation ) {
        ui.qrcode.create( qrInformation );
        longRequest();
    });
}

/**
    cb -> callback.
    callback( array );
    array -> devices list.
*/
function checkDevicesPair( cb ) {
    cb = typeof cb === 'function' ? cb : noop;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if ( xhr.readyState == 4 ) {
            if ( xhr.status >= 200 && xhr.status < 300 || xhr.status === 304 ) {
                var result;
                try {
                    result = JSON.parse( xhr.responseText );
                }
                catch(e) {
                    alert( '服务器已不再支持此版本扩展' );
                }
                cb( result );
            }
            else {
                cb( 'cb: callback' );
            }
        }
    };
    xhr.open( 'GET', 'http://sync.mse.sogou.com/checkpair?hid=' + getHid(), 'true' );
    xhr.send( null );
}

/**
    state: 1,   // error.
    uuid: .....,//
    hid: .......//
*/
function delDevices( uuid, cb ) {
    cb = typeof cb !== 'undefined' ? cb : noop;
    if ( !uuid ) return cb( new Error('arguments error') );
    // http://sync.mse.sogou.com/delcouple
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if ( xhr.readyState === 4 ) {
            if ( xhr.status >= 200 && xhr.status < 300 || xhr.status === 304 ) {
                var result;
                try {
                    result = JSON.parse( xhr.responseText );
                }
                catch(e) {
                    alert( '服务器已不再支持此版本扩展' );
                }
                cb( result );
            }
            else {
                alert( '删除设备失败, 请确认网络是否正常.' );
            }
        }
    };
    xhr.open( 'GET', 'http://sync.mse.sogou.com/delcouple?hid=' + getHid() + '&uuid=' + uuid, true );
    xhr.send( null );
}

function sendText( data, callback ) {
    callback = typeof callback === 'function' ? callback : noop;
    if( Object.prototype.toString.call(data) !== '[object Object]' ) return;
    var text = data.text;
    if ( !text ) return;
    var title = data.title;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if ( xhr.readyState === 4 ) {
            if ( xhr.status >= 200 && xhr.status < 300 || xhr.status === 304 ) {
                callback( xhr.responseText );
            }
        }
    };
    xhr.open( 'POST', 'http://sync.mse.sogou.com/sendtext', true );
    var data = {
        hid: getHid(),
        uuid: currentUUID.get(),
        data: text,
        title: title || ''
    };
    xhr.send( JSON.stringify(data) );
}

function sendURL( data, callback ) {
    callback = typeof callback === 'function' ? callback : noop;
    data = data || {};
    var url = data.url;
    var title = data.title;
    if ( !url ) return;
    // http://sync.mse.sogou.com/sendurl
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if ( xhr.readyState === 4 ) {
            if ( xhr.status >= 200 && xhr.status < 300 || xhr.status === 304 ) {
                callback( xhr.responseText );
            }
        }
    };
    xhr.open( 'POST', 'http://sync.mse.sogou.com/sendurl', true );
    var data = {
        hid: getHid(),
        uuid: currentUUID.get(),
        data: url,
        title: title || ''
    };
    xhr.send( JSON.stringify(data) );
}

function __sendFile( formdata, callback ) {
    callback = typeof callback === 'function' ? callback : noop;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if ( xhr.readyState === 4 ) {
            if ( xhr.status >= 200 && xhr.status < 300 || xhr.status === 304 ) {
                callback( xhr.responseText );
            }
            else {
                alert( '上传文件失败. 请确认网络是否正常' );
            }
        }
    };
    xhr.open( 'POST', 'http://sync.mse.sogou.com/sendfile', true );
    xhr.upload.addEventListener( 'progress', uploadProgress, false);
    xhr.addEventListener('loadstart', uploadStart, false);
    xhr.addEventListener('progress', uploadProgress, false);
    xhr.addEventListener('load', uploaded, false);
    xhr.addEventListener('error', uploadError, false);
    xhr.addEventListener('abort', uploadAbort, false);
    xhr.addEventListener('loadend', uploadEnd, false);
    xhr.send( formdata );
}

function uploadStart( event ) {
    console.log( 'start: ', arguments );
    console.log( 'start fileSize: ', event.totalSize );
}

function uploadProgress( event ) {
    if ( event.lengthComputable ) {
        ui.uploadProgress( event.loaded, event.total );
    }
}

function uploaded() {
    console.log( 'uploaded: ', arguments );
}

function uploadError() {
    console.log( 'upload error: ', arguments );
}

function uploadAbort() {
    console.log( 'upload abort: ', arguments );
}

function uploadEnd() {
    console.log( 'upload always: ', arguments );
}

// send file api.
function sendFiles( files ) {
    var formdata = new FormData();
    formdata.append( 'hid', getHid() );
    formdata.append( 'uuid', currentUUID.get() );

    var exceedLimitedFile = [];
    for ( var i = 0; i < files.length; i++ ) {
        var file = files[i];
        if ( file.size <= 1024 * 1024 * 20 ) {
            formdata.append( 'tinyfile', files[i] );
        }
        else {
            exceedLimitedFile.push( file );
        }
    }

    if ( exceedLimitedFile.length > 0 ) {
        ui.exceedLimitedFileSize( exceedLimitedFile );
    }

    if ( exceedLimitedFile.length === files.length ) {
        return;
    }

    __sendFile( formdata, function( response ) {
        /*
            {
                ret: 1 // 设备已解除绑定.
                ret: 0 // 发送成功.
            }
        */
        console.log( 'sendfile end!', response );
    });
}

function getHid() {
    var result = localStorage[ storage_key_hid ];
    if ( !result ) {
        result = MD5(newGuid()).toUpperCase();
        localStorage[ storage_key_hid ] = result;
    }
    return result;
}

var currentUUID = (function() {
    return {
        set: function( uuid ) {
            localStorage[ current_uuid_key ] = uuid;
        },
        get: function() {
            return localStorage[ current_uuid_key ];
        },
        // 初始化.
        init: function( list ) {
            if ( typeof list != 'object' ) return;
            if ( !list.length ) return;
            // list 要求是 array.
            var current = this.get();
            // 不存在 current, 即首次绑定.
            // 绑定过, 但原 uuid 已经不存在 - 即手机端已经删除设备.(目前是这样)
            if ( !current || list.every(function( device ){
                return device.uuid === current;
            })) {
                return this.set( list[list.length-1].uuid );
            }
        }
    };
})();

// @NOTE: 采用技术角度解决 - 先 checkpair
function launchApp( list ) {
    ui.init( list );
    if ( list.length > 0 ) {
        currentUUID.init( list );
        ui.qrcode.clear();
    }
    else {
        createQRcode();
    }
}

function initApp() {
    checkDevicesPair( launchApp );
}

[
    'sendURL',
    'sendText',
    'delDevices',
    'initApp',
    'requestQRData',
    'checkDevicesPair'
].forEach(function( item ) {
    window[ item ] = aop( window[item], function( next ) {
        ui.request.sendRequestStart();
        next();
        ui.request.sendRequestEnd();
    });
});

initApp();
