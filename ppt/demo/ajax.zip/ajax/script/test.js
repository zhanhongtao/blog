

// 发送 url - ok
var testSendURL = aop( sendURL, function( option, next ) {
    return option.ok ? '' : next();
});
testSendURL({
    ok: true,
    url: 'http://www.baidu.com',
    title: '百度'
}, function( result ) {
    console.log( result );
});

// 发送文本内容.
var testSendText = aop( sendText, function( option, next ) {
  return option.ok ? '' : next();
});

var tabapi = new mx.browser.tabs();
var tab = tabapi.getCurrentTab();
testSendText({
  ok: true,
  text: 'test sendText api content',
  title: 'test sendText api title'
}, function( result ) {
  console.log( result );
});

// 删除设备.
var testDelDevices = aop( delDevices, function( option, cb, next ) {
  if ( !option.ok ) {
    next( option.uuid, cb );
  }
});

// 删除当前选择设备.
testDelDevices( {
  ok: true,
  uuid:  currentUUID.get()
} , function( result ) {
  console.log( result );
});

