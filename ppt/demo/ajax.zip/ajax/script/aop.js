

function aop( self, func ) {
    return function() {
        var _arguments = arguments;
        var next = function() {
            var argus = arguments.length ? arguments : _arguments;
            return self.apply( null, argus );
        };
        var argus = [].slice.call( arguments );
        var length = func.length;
        argus = length < 2 ? [] : argus.slice( 0, length - 1);
        argus.push( next );
        return func.apply( null, argus );
    };
}

